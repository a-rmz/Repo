package gameManager.levels;

import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;

import Effects.SoundEffects;
import background.Background;
import characters.Ship;
import cinematics.NewGameCM;

import gameManager.GameState;
import gameManager.GameStateManager;
import managers.EnemyManager;


@SuppressWarnings("serial")
public class Level1 extends GameState {
	
	
	// Atributes
	GameStateManager gsm;
	Ship p1;
	public EnemyManager e;
	public NewGameCM cinematic;
	SoundEffects se ;
	
	// Graphics
	Background bg;
	
		
	public Level1(GameStateManager gsm){
		this.gsm = gsm;
		p1 = Ship.getPlayer();
		bg = new Background(Background.LEVEL_1);
		e = new EnemyManager(2, 4, 20); //TODO
		cinematic = new NewGameCM();
		se = new SoundEffects();
		se.FXSound(7);
		
	}
	
	public void restartLevel() {
		
	}
	
	public void  initCinematic(){
		cinematic.startAnimation();
	}
	
	@Override
	public void draw(Graphics2D g2d){
		
		Graphics g = g2d;
		
		// Prints the Background
		bg.draw(g2d);
		
		// Prints enemies
		if(cinematic.enemyAppears)  e.draw(g);
		
		// Prints user Ship
		p1.draw(g);
		
		
//*******************************************************************//
		
		// Prints cinematic
		
		if(cinematic.isRunning){ 
			cinematic.draw(g);
		}
		
	}


	@Override
	public void update(){
		bg.update();
		p1.update();
		
		if(!cinematic.endCinematic()){
			se.play();
		}
		
		if( p1.isAlive() == false) {
			se.stop();
		}
		
		if(cinematic.enemyAppears) e.update();
		
		if(!Ship.getPlayer().isAlive()) {
			gsm.endGame();
		}
		
	}

	
	@Override
	public void init() {
		
	}

	
	@Override
	public void keyPressed(int k) {
		if(k == KeyEvent.VK_ESCAPE) se.stop();
		p1.keyPressed(k);		
	}

	@Override
	public void keyReleased(int k) {
		p1.keyReleased(k);
		
	}

	@Override
	public void mouseMoved(MouseEvent e) {
		p1.mouseMoved(e);
	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		p1.mousePressed(e);
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		p1.mouseReleased(e);
	}
	
	@Override
	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub

	}

}
